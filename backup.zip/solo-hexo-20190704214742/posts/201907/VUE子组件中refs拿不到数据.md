title: VUE 子组件中 $refs 拿不到数据
date: '2019-07-04 16:14:25'
updated: '2019-07-04 16:20:53'
tags: [VUE, 前端]
permalink: /articles/2019/07/04/1562228065394.html
---
![](https://img.hacpai.com/bing/20181104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1. `this.$refs.xxx`一定要放到`this.$nextTick`的方法内执行，或者在setTimeout中执行，延迟时间一般20ms就可以

2. 也可以用`watch`来监听`data`，当data接受到父组件传来的数据，再在`this.$nextTick`内获取`this.$refs.xxx`

	```
	watch:{
	    data(){
	        this.$nextTick(_=>{
	            this.$refs.xxx
	        })
	    }
	}
	```