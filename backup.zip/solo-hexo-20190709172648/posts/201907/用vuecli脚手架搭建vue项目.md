title: 用vue-cli(脚手架)搭建vue项目
date: '2019-07-04 16:20:00'
updated: '2019-07-04 17:13:01'
tags: [VUE, 前端]
permalink: /articles/2019/07/04/1562228400913.html
---
![](https://img.hacpai.com/bing/20180731.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

现在最新的VUE脚手架是3.0，大部分的VUE框架也在兼容VUE3.0的脚手架，新的脚手架支持网页端的操作，非常的方便。
![image.png](https://img.hacpai.com/file/2019/07/image-fd64245a.png)
安装也很简单，接下来就看一下怎么安装吧
```shell
npm install --global vue-cli #（–global：全局安装vue-cli）此为vue2.X版本

# cmd到自己的项目工作空间
vue init webpack test #（其中test为我的项目名称）

# 如今 vue官方最新的为3.X
# 如果你已经安装了vue2.X,则先卸载
npm uninstall -g vue-cli 

# vue cli 要求node 8.0+ 直接跟新到最新版就好
npm install -g @vue/cli
# OR 
yarn global add @vue/cli

# vue cli 3.0 支持通过命令行执行 'vue ui' 运行一个网页 默认为'localhost:8000' 进行创建，导入，添加插件、依赖，和运行等操作
```
