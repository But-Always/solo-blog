title: asar的基本操作
date: '2019-07-04 16:23:18'
updated: '2019-07-04 16:23:18'
tags: [asar]
permalink: /articles/2019/07/04/1562228598330.html
---
app.asar文件是Electron程序的主业务文件，是一种压缩格式的文件
### 安装
`默认已经安装npm和nodejs环境`
```
# 命令行下安装asar
npm install -g asar
# 确认是否安装成功
asar -V
```
### 打包asar文件
```
asar pack `you-app` app.asar
# you-app: 文件夹路径,指向的文件夹下的所有文件都会被打包到app.asar下
```
### 解压asar文件
```
asar extract `app.asar` `./`
# app.asar: 需要解压缩的asar文件
# ./: 解压缩之后文件存放的路径
```